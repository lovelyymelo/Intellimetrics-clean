<p className="text-sm text-muted-foreground">
  © {new Date().getFullYear()} IntelliMetrics. One platform. Total control. Infinite growth.
</p>